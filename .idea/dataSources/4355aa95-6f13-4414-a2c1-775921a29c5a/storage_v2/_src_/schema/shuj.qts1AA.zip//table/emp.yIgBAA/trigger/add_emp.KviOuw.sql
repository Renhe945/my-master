create definer = root@localhost trigger add_emp
    after insert
    on emp
    for each row
begin  
		    #  向 日志表中 记录  员工的编号  和 名称 以及 什么时候 添加的数据
				  insert   into    logs  values(null,new.eid,new.ename,now());
		
		  end;

