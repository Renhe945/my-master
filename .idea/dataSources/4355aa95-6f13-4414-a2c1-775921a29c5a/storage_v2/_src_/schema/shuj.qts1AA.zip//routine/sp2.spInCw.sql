create
    definer = root@localhost procedure sp2(IN ename varchar(255), IN sex char(10), IN sal double(10, 2),
                                           IN hobby varchar(40), IN content varchar(255), IN did int)
begin 
 
   insert  into    emp   values(null,ename,sex,sal,default,hobby,now(),null,content,did);
			
end;

