create
    definer = root@localhost procedure sp1()
begin  
	
		insert  into    dept  values(null,'财务部'),
						                    (null,'公关部'),
																(null,'研发部'),
																(null,'行政部');
		end;

